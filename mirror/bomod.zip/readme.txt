Buffer Overflow Module

�2002,  Susan Gerhart, Jan G. Hogle, Jedidiah R. Crandall. 
Distributed July 2002.

This Project was Funded by the National Science Foundation Federal Cyber Service Scholarship For Service Program: Grant No. 0113627

For more information, go to: http://nsfsecurity.pr.erau.edu 
or contact Dr. Susan Gerhart, gerharts@erau.edu 
Embry-Riddle Aeronautical University 
Prescott, Arizona USA


-------------------

To run the Authorware Interactive module, click on "bomod.exe".

Buffer Overflow Demos may be run locally or from our nsfsecurity.pr.erau.edu Web site. The demos are applets and require a Java-enabled browser. If you do not have Java installed on your computer, download the latest runtime version from www.download.com. To run the demos locally on your computer, open "index.html" in the "bom" folder. 
 
Ready-to-use Powerpoint presentations, pdf documents, and defense tools, may be found in the "bom-docs" folder. Adobe Acrobat Reader is available in the "Viewers" folder or may be downloaded free from www.adobe.com. Powerpoint presentations require Powerpoint applicaiton, or a PowerPoint viewer, available as a free download from www.microsoft.com.

---------------------

Please complete a feedback form at http://nsfsecurity.pr.erau.edu/feedback.html to tell us how you used this material and to offer suggestions for improvements.

This document is part of a larger package of materials on Aviation Security issues, such as Cryptography, Overview of Security Dimensions, and Personnel Security. 
See http://nsfsecurity.pr.erau.edu for more information.



